/*
 * Graph sorting the files according to:
 *  - unknown files
 *  - authored or mixed code
 *  - auto-generated files
 *  - external files
 */
var fileOriginality = [#text#];
