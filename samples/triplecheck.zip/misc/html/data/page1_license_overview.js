var licenseOverview = [
#text#
];
