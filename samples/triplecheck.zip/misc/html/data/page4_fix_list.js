// What should be fixed on this project? 
var fix_copyright = "fCop";
var fix_licenses = "fLic";
var fix_documentation = "fDoc";




