var dataFileTypes = [
#fileTypeData#
];

var fileTypeText = "#fileTypeText#";