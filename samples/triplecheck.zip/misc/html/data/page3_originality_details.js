// what titles shall we show for the titles on the originality analysis?
var match_similar_title = "#title_similar#";
var match_exact_title = "#title_exact#";

// is there a list of items that we should show?
var match_similar_list = [
#text_similar#
];

var match_exact_list = [
#text_exact#
];
